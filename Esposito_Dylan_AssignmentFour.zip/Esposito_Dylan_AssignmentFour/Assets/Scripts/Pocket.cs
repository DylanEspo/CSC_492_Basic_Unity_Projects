﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class Pocket : MonoBehaviour {
    
    //keeps score value
    public float score = 0;
    //Function that is activated when the gameObject colldies with another object
    public void Start()
    {
        //Debug.Log("Script Running");
    }

    void OnTriggerEnter(Collider other)
    {
        //if the game object we collided with has a tag of "Hole" than we deactivate our own 
        //object. Basically as soon as the pool ball reaches a pocket, it is deactivated.
        if (other.gameObject.CompareTag("PoolBall"))
        {
            //set the pool ball to false
            other.gameObject.SetActive(false);
            //increment score by one
            score += 1;
            //print(score);
        }

        //checks if score is greater than or equal to 8, the number of poolballs
        if(score >= 8)
        {
            //Load the GameOver scene
            SceneManager.LoadScene("GameOver");
        }

    }
}
