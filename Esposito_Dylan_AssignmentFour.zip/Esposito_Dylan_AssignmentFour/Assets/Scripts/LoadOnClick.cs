﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

using UnityEngine;

public class LoadOnClick : MonoBehaviour {

	// Use this for initialization
	public void LoadGame(int level)
    {
        //maybe make an exception block

        //Load pool Game
        SceneManager.LoadScene("PoolGame");
    }

    //This loads back the main menu
    public void LoadMenu(int level)
    {
        //make a call to the MainMenu
        SceneManager.LoadScene("MainMenu");
    }
}
