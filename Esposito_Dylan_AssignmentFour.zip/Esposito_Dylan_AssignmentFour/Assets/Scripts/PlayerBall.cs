﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBall : MonoBehaviour {

    // Use this for initialization
    private Rigidbody playerPB;

    //activated when player is charging shot
    bool chargeShot = false;

    //set playerSpeed inital value to ten
    public float playerSpeed = 10;

    //Activate rigidboy
    void Start () {
        playerPB = GetComponent<Rigidbody>();
	}

    // Update is called once per frame
    void Update()
    {
        //checks if mouse button is held down
        if (Input.GetMouseButtonDown(0))
        {
            //set chargeShot to true
            chargeShot = true;
        }
        //check if MouseButton is up if so move pool ball
        if (Input.GetMouseButtonUp(0)){
            //chargeShot set to false
            chargeShot = false;
            Debug.Log("Mouse clicked");
            //Apply ray to screen and vreate raycast titled screen
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            //Check if raycast is within target
            if (Physics.Raycast(ray, out hit, 400))
            {
                //call moveBall function
                movePoolBall(hit.point);
            }
        }
        //check if ChargeShot is true
        if (chargeShot == true)
        {
            //check if plyaerSpeed is less than 500, if so update playerSpeed by 5
            if (playerSpeed < 500)
            {
                Debug.Log("ChargingUp");
                playerSpeed += 5;
                //print(playerSpeed);
            }
        }
    }

    //movePoolBall in direction
    void movePoolBall(Vector3 target)
    {
        //Rotate ball into direction of target location
        playerPB.transform.LookAt(target);
        //add force to player, direction is forward and it is multiplied by the current speed.
        //ForceMode set to impulse to add more power to playerBall
        playerPB.AddForce(transform.forward * playerSpeed, ForceMode.Impulse);
        //reset playrSpeed to ten so it doesn't carry over on next hit
        playerSpeed = 10;
    }
}
