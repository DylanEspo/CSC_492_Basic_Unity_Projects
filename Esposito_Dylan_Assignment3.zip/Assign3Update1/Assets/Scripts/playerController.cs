﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class playerController : MonoBehaviour {

    /// <summary>
    /// Reference to the player rigid body
    /// </summary>
    private Rigidbody _player_rb;

    //Vector3s used to determine movement both up and to the right
    public Vector3 goUp;
    public Vector3 moveRight;

    /// <summary>
    /// Reference to the player's camera
    /// </summary>
    //Camera object that is used to follow player's position
    public Camera _player_cam;

    //Text objects that keep track of score and lives
    public Text _score_text;
    public Text _lives_text;

    /// <summary>
    /// Control speed
    /// </summary>
    public float _speed = 200f;

    /*
     * Create score variable that is initally not assigned a value. Upon building the game, the score will automatically
     * be assigned to zero. However since we declare score as static, then the value assigned to score upon reaching the
     * end of the scene it will be carried over into the next level.
    */
    public static float _score;

    public static float _lives;

    /// <summary>
    /// Follow camera offset
    /// </summary>
    Vector3 _offset;

    /// <summary>
    /// Initialize the scene.
    /// Stores camera offset positioning
    /// </summary>
    void Start () {


        //Assign the player a rigid boy attribute
        _player_rb = GetComponent<Rigidbody>();

        //Set the current value of _lives equal to the value stored in the PlayersPreferences float called "lives"
        _lives = PlayerPrefs.GetFloat("lives");

        //Offset camera to the position of the player
         _offset = _player_cam.transform.position - _player_rb.transform.position;

        //Initalize text displaying the word "Score" as well as the value store in score
        _score_text.text = "Score: " + _score;

        _lives_text.text = "Lives: " + _lives;
       

        //Sets variables that will determine movement of player object
        goUp = new Vector3(0.0f, 4.0f, 0.0f);
        moveRight = new Vector3(12f, 0f, 0f);
    }



    /// <summary>
    /// Movement control for the player and camera.
    /// Updates every frame
    /// </summary>
    void Update () {

        //Allows us to add momentum to player object. 
        _player_rb.AddForce(moveRight);

        //Allows us to continually update the players position in every frame.
        _player_cam.transform.position = _player_rb.position + _offset;

        //Check if user is pressing teh space key, if so we move upwards
        if (Input.GetMouseButtonDown(0))
        {
            _player_rb.AddForce(goUp * 10.0f, ForceMode.Impulse);
        }


    }

    //Method used to check if user has entered a object with a trigger assigned to it.
    private void OnTriggerEnter(Collider other)
    {
        //Check if object is tagged as a collectible
        if (other.CompareTag("Wall"))
        {
            //Update the value stored in "_lives" by one
           _lives = _lives - 1;

            if (_lives >= 0)
            {
                //Updates playersprefs with new value of _lives
                PlayerPrefs.SetFloat("lives", _lives);
                //Reloads scene with updated values
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            }
            else
            {
                PlayerPrefs.SetString("result", "l");
                SceneManager.LoadScene("5GameOver");
            }
            _score = 0;

        }
        else if (other.CompareTag("ScoreCollider")){

           //Update the value stored in "_score" by one
           _score = _score + 1;
           //Update the value stored in the _score_text variable
           _score_text.text = "Score: " + _score.ToString();
           //tell debugger that a collectible has been retrieved
           Debug.Log("Score Registered");
           //set the collectible that we have collided with to false.
           //other.gameObject.SetActive(false);
           


        }
        //checks if the object is tagged as Finish, meaning we reached the end of the maze
        else if (other.CompareTag("Finish"))
        {
            //create string in playersprefs titled result
            PlayerPrefs.SetString("result", "w");

            //after reaching the finish trigger, Unity will check if there is another scene coming up. If so it will load that scene in.
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);

        }

        //when picking up trigger, 
    }



}
