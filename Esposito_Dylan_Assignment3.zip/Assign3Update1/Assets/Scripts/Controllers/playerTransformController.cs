﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerTransformController : MonoBehaviour {

    /// <summary>
    /// Reference to the player rigid body
    /// </summary>
    private Rigidbody _player_rb;

    /// <summary>
    /// Reference to the player's camera
    /// </summary>
    public Camera _player_cam;

    /// <summary>
    /// Control speed
    /// </summary>
    public float _speed = 200f;

    /// <summary>
    /// Follow camera offset
    /// </summary>
    Vector3 _offset;

    /// <summary>
    /// Initialize the scene.
    /// Stores camera offset positioning
    /// </summary>
    void Start()
    {

        _player_rb = GetComponent<Rigidbody>();

        _offset = _player_cam.transform.position - _player_rb.transform.position;
    }



    /// <summary>
    /// Movement control for the player and camera.
    /// Updates every frame
    /// </summary>
    void Update()
    {

        float moveVertical = Input.GetAxis("Vertical");
        float moveHorizontal = Input.GetAxis("Horizontal");

        Vector3 movementVec = new Vector3(moveHorizontal, 0, moveVertical);

        transform.Translate(movementVec * _speed * Time.deltaTime);
        _player_cam.transform.position = _player_rb.position + _offset;


    }
}
