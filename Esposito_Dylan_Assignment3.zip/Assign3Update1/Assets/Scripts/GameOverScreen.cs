﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameOverScreen : MonoBehaviour {

    //string used to retrieve valued passed through PlayerPrefs
    public string final;

    //Text object that will display whether or not the user has won
    public Text result_final;
	// Use this for initialization
	void Start () {

        //retrieve value stored in result variable which itself is stored in the PlayerPrefs object
        final = PlayerPrefs.GetString("result");
        
        //Displays "You Win" to the user otherwise it displays they lost
        //if the value final pulled is a w taht indicates they had won otherwise they had lost
        if(final == "w")
        {
            result_final.text = "You win!";
        }
        else
        {
            result_final.text = "You lose!";
        }
		
	}

}
