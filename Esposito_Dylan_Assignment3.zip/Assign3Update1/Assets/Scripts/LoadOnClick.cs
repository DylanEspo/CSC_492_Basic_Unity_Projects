﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
//using playerController.cs;
using UnityEngine;

public class LoadOnClick : MonoBehaviour
{

    //Default mode with fives lives assigned
    public void LoadScene(int level)
    {
        //Create a variable within the PlayerPrefs object that stores the value of five into 
        //the variable lives. This value will be retrieved by the playerController class 
        PlayerPrefs.SetFloat("lives", 5);
        //Debug.Log("Medium");


        //Here we load the first level
        SceneManager.LoadScene("3Level1");
    }

    public void PickDifficulty(int level)
    {
        switch (level)
        {
            case 1:
                PlayerPrefs.SetFloat("lives", 8);
                Debug.Log("Easy");
                SceneManager.LoadScene("3Level1");
                break;
            case 2:
                PlayerPrefs.SetFloat("lives", 5);
                Debug.Log("Medium");
                SceneManager.LoadScene("3Level1");
                break;
            case 3:
                PlayerPrefs.SetFloat("lives", 3);
                Debug.Log("Hard");
                SceneManager.LoadScene("3Level1");
                break;
        }
    }

    //Will load hard mode with 3 lives assigned
    public void LoadSceneHard(int level)
    {
        //Create a variable within the PlayerPrefs object that stores the value of three into 
        //the variable lives. This value will be retrieved by the playerController class 
        PlayerPrefs.SetFloat("lives", 3);
        //Debug.Log("Hard");

        //Loads the first level
        SceneManager.LoadScene("3Level1");
    }

    //Will load easy mode with 8 lives assigned
    public void LoadSceneEasy(int level)
    {
        //Create a variable within the PlayerPrefs object that stores the value of eight into 
        //the variable lives. This value will be retrieved by the playerController class 
        PlayerPrefs.SetFloat("lives", 8);

        //Debug.Log("Easy");

        //Loads the first level
        SceneManager.LoadScene("3Level1");
    }

    //Will load options scene
    public void LoadOptions(int level)
    {
        SceneManager.LoadScene("2Options");
    }

    //Will load Main Menu scene
    public void LoadMainMenu(int level)
    {
        SceneManager.LoadScene("1MainMenu");
    }
}
